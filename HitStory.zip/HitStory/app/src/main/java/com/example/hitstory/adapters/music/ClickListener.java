package com.example.hitstory.adapters.music;

public interface ClickListener {
    void click(int position);
}
