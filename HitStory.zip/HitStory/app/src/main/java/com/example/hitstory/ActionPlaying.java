package com.example.hitstory;

public interface ActionPlaying {
    void playPauseBtnClicked();
    void previousBtnClicked();
    void nextBtnClicked();
}
